/*==========================================================
app.js
==========================================================*/

document.addEventListener("DOMContentLoaded", () => {

    /*=========================================
      Sticky Header
    =========================================*/

    const header = document.querySelector(".header");

    function stickyHeader() {

        if (window.scrollY > 40) {

            header.classList.add("header--scrolled");

        } else {

            header.classList.remove("header--scrolled");

        }

    }

    stickyHeader();

    window.addEventListener("scroll", stickyHeader);

    /*=========================================
      Smooth Scroll
    =========================================*/

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {

        anchor.addEventListener("click", function (event) {

            const target = document.querySelector(
                this.getAttribute("href")
            );

            if (!target) return;

            event.preventDefault();

            window.scrollTo({

                top: target.offsetTop - 90,

                behavior: "smooth"

            });

        });

    });

    /*=========================================
      Active Navigation
    =========================================*/

    const sections = document.querySelectorAll("section[id]");
    const navLinks = document.querySelectorAll(".header__nav a");

    window.addEventListener("scroll", () => {

        let current = "";

        sections.forEach(section => {

            const top = section.offsetTop - 150;
            const height = section.offsetHeight;

            if (

                pageYOffset >= top &&
                pageYOffset < top + height

            ) {

                current = section.id;

            }

        });

        navLinks.forEach(link => {

            link.classList.remove("active");

            if (

                link.getAttribute("href") === "#" + current

            ) {

                link.classList.add("active");

            }

        });

    });

    /*=========================================
      Enquiry Form
    =========================================*/

    const form = document.querySelector(".enquiry__form");

    if (form) {

        form.addEventListener("submit", e => {

            e.preventDefault();

            const fields = form.querySelectorAll(

                "input,select"

            );

            let valid = true;

            fields.forEach(field => {

                if (

                    field.value.trim() === ""

                ) {

                    field.style.borderColor = "#e53935";

                    valid = false;

                } else {

                    field.style.borderColor = "#18c16e";

                }

            });

            if (!valid) {

                alert("Please fill all the required fields.");

                return;

            }

            alert(

                "Thank you! We will contact you shortly."

            );

            form.reset();

        });

    }

    /*=========================================
      Lazy Loading
    =========================================*/

    document.querySelectorAll("img").forEach(image => {

        image.loading = "lazy";

    });

    /*=========================================
      Parallax Background
    =========================================*/

    const hero = document.querySelector(".hero");

    if (hero) {

        hero.addEventListener("mousemove", event => {

            const circles = document.querySelectorAll(

                ".hero__circle"

            );

            const x = event.clientX / window.innerWidth;
            const y = event.clientY / window.innerHeight;

            circles.forEach((circle, index) => {

                const speed = (index + 1) * 18;

                circle.style.transform =

                    `translate(${x * speed}px,${y * speed}px)`;

            });

        });

        hero.addEventListener("mouseleave", () => {

            document.querySelectorAll(

                ".hero__circle"

            ).forEach(circle => {

                circle.style.transform = "";

            });

        });

    }

    /*=========================================
      Button Ripple
    =========================================*/

    document.querySelectorAll(".button").forEach(button => {

        button.addEventListener("click", function (event) {

            const ripple = document.createElement("span");

            ripple.className = "ripple";

            ripple.style.left =

                event.offsetX + "px";

            ripple.style.top =

                event.offsetY + "px";

            this.appendChild(ripple);

            setTimeout(() => {

                ripple.remove();

            }, 600);

        });

    });

    /*=========================================
      Console
    =========================================*/

    console.log(

        "%cPremier Schools Exhibition Loaded",

        "color:#0b7ad1;font-size:16px;font-weight:bold;"

    );

});