/*==========================================================
accessibility.js
==========================================================*/

document.addEventListener("DOMContentLoaded", () => {

    /*=========================================
      Mobile Navigation
    =========================================*/

    const menuButton = document.querySelector(".header__toggle");
    const navigation = document.querySelector(".header__nav");

    if (menuButton && navigation) {

        menuButton.setAttribute("aria-expanded", "false");

        menuButton.addEventListener("click", () => {

            const expanded =
                menuButton.getAttribute("aria-expanded") === "true";

            menuButton.setAttribute(
                "aria-expanded",
                String(!expanded)
            );

            navigation.classList.toggle("active");

        });

    }

    /*=========================================
      ESC closes mobile menu
    =========================================*/

    document.addEventListener("keydown", e => {

        if (e.key === "Escape") {

            navigation?.classList.remove("active");

            menuButton?.setAttribute(
                "aria-expanded",
                "false"
            );

        }

    });

    /*=========================================
      Keyboard Focus
    =========================================*/

    const focusable = document.querySelectorAll(
        "a,button,input,select,textarea"
    );

    if (focusable.length) {

        const first = focusable[0];
        const last = focusable[focusable.length - 1];

        document.addEventListener("keydown", e => {

            if (e.key !== "Tab") return;

            if (e.shiftKey) {

                if (document.activeElement === first) {

                    e.preventDefault();
                    last.focus();

                }

            } else {

                if (document.activeElement === last) {

                    e.preventDefault();
                    first.focus();

                }

            }

        });

    }

    /*=========================================
      Reveal Animation
    =========================================*/

    const reveals = document.querySelectorAll(

        ".feature,.gallery__card,.category,.trust__card,.school"

    );

    const observer = new IntersectionObserver(

        entries => {

            entries.forEach(entry => {

                if (entry.isIntersecting) {

                    entry.target.classList.add("fade-up");

                }

            });

        },

        {

            threshold:0.15

        }

    );

    reveals.forEach(item => observer.observe(item));

    /*=========================================
      Back To Top
    =========================================*/

    const topButton = document.createElement("button");

    topButton.className = "back-to-top";

    topButton.setAttribute(
        "aria-label",
        "Back To Top"
    );

    topButton.innerHTML = "↑";

    document.body.appendChild(topButton);

    window.addEventListener("scroll", () => {

        if (window.scrollY > 500) {

            topButton.classList.add("show");

        } else {

            topButton.classList.remove("show");

        }

    });

    topButton.addEventListener("click", () => {

        window.scrollTo({

            top:0,
            behavior:"smooth"

        });

    });

    /*=========================================
      Reduced Motion
    =========================================*/

    if (
        window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {

        document.documentElement.style.scrollBehavior = "auto";

        document.querySelectorAll("*").forEach(el => {

            el.style.animation = "none";
            el.style.transition = "none";

        });

    }

});