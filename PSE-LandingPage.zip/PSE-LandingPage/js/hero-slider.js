/*==========================================================
hero-slider.js
==========================================================*/

document.addEventListener("DOMContentLoaded", () => {

    const columns = document.querySelectorAll(".hero__gallery-column");
    const studentName = document.querySelector(".hero__student-info h4");
    const studentSchool = document.querySelector(".hero__student-info p");
    const studentImage = document.querySelector(".hero__student-avatar img");

    if (!columns.length) return;

    const students = [

        {
            name: "Tejaswini Patil",
            school: "DPS International School",
            image: "https://images.pexels.com/photos/5212695/pexels-photo-5212695.jpeg?auto=compress&cs=tinysrgb&w=300"
        },

        {
            name: "Aarav Sharma",
            school: "Heritage Xperiential",
            image: "https://images.pexels.com/photos/8926554/pexels-photo-8926554.jpeg?auto=compress&cs=tinysrgb&w=300"
        },

        {
            name: "Ananya Kapoor",
            school: "Pathways World School",
            image: "https://images.pexels.com/photos/8423395/pexels-photo-8423395.jpeg?auto=compress&cs=tinysrgb&w=300"
        },

        {
            name: "Vihaan Singh",
            school: "Shiv Nadar School",
            image: "https://images.pexels.com/photos/8617807/pexels-photo-8617807.jpeg?auto=compress&cs=tinysrgb&w=300"
        }

    ];

    let index = 0;

    function updateStudentCard() {

        if (!studentName) return;

        studentName.style.opacity = "0";
        studentSchool.style.opacity = "0";
        studentImage.style.opacity = "0";

        setTimeout(() => {

            studentName.textContent = students[index].name;
            studentSchool.textContent = students[index].school;
            studentImage.src = students[index].image;

            studentName.style.opacity = "1";
            studentSchool.style.opacity = "1";
            studentImage.style.opacity = "1";

            index++;

            if (index >= students.length) {

                index = 0;

            }

        }, 350);

    }

    setInterval(updateStudentCard, 3500);

    columns.forEach((column, i) => {

        column.animate(

            [

                {
                    transform: "translateY(0px)"
                },

                {
                    transform: `translateY(${i % 2 === 0 ? "-20px" : "20px"})`
                },

                {
                    transform: "translateY(0px)"
                }

            ],

            {

                duration: 5000 + i * 600,

                iterations: Infinity,

                easing: "ease-in-out"

            }

        );

    });

    const images = document.querySelectorAll(".hero__image img");

    images.forEach((image) => {

        image.addEventListener("mouseenter", () => {

            image.style.transform = "scale(1.08)";

        });

        image.addEventListener("mouseleave", () => {

            image.style.transform = "scale(1)";

        });

    });

    const hero = document.querySelector(".hero");

    hero.addEventListener("mousemove", (event) => {

        const x = (event.clientX / window.innerWidth - 0.5) * 20;
        const y = (event.clientY / window.innerHeight - 0.5) * 20;

        columns.forEach((column, index) => {

            const depth = (index + 1) * 4;

            column.style.transform =
                `translate(${x / depth}px, ${y / depth}px)`;

        });

    });

    hero.addEventListener("mouseleave", () => {

        columns.forEach((column) => {

            column.style.transform = "";

        });

    });

});