/*==========================================================
school-slider.js
==========================================================*/

document.addEventListener("DOMContentLoaded", () => {

    const slider = document.querySelector(".features__slider");
    const track = document.querySelector(".features__track");

    const slides = document.querySelectorAll(".feature");

    const next = document.querySelector(".features__next");
    const prev = document.querySelector(".features__prev");

    if (!slider || !track || slides.length === 0) return;

    let current = 0;

    const gap = 30;

    function visibleSlides() {

        if (window.innerWidth < 768) return 1;

        if (window.innerWidth < 1200) return 2;

        return 3;

    }

    function slideWidth() {

        return slides[0].offsetWidth + gap;

    }

    function maxSlide() {

        return Math.max(
            slides.length - visibleSlides(),
            0
        );

    }

    function updateSlider() {

        track.style.transform =
            `translateX(-${current * slideWidth()}px)`;

    }

    next.addEventListener("click", () => {

        current++;

        if (current > maxSlide()) {

            current = 0;

        }

        updateSlider();

    });

    prev.addEventListener("click", () => {

        current--;

        if (current < 0) {

            current = maxSlide();

        }

        updateSlider();

    });

    /*--------------------------------------
      Auto Slide
    --------------------------------------*/

    let auto = setInterval(() => {

        next.click();

    }, 3500);

    slider.addEventListener("mouseenter", () => {

        clearInterval(auto);

    });

    slider.addEventListener("mouseleave", () => {

        auto = setInterval(() => {

            next.click();

        }, 3500);

    });

    /*--------------------------------------
      Touch Swipe
    --------------------------------------*/

    let startX = 0;
    let endX = 0;

    slider.addEventListener("touchstart", e => {

        startX = e.touches[0].clientX;

    });

    slider.addEventListener("touchmove", e => {

        endX = e.touches[0].clientX;

    });

    slider.addEventListener("touchend", () => {

        const distance = startX - endX;

        if (distance > 60) {

            next.click();

        }

        if (distance < -60) {

            prev.click();

        }

    });

    window.addEventListener("resize", updateSlider);

    updateSlider();

});