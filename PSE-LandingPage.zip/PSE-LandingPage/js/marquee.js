/*==========================================================
marquee.js
==========================================================*/

document.addEventListener("DOMContentLoaded", () => {

    const slider = document.querySelector(".schools__slider");
    const track = document.querySelector(".schools__track");

    if (!slider || !track) return;

    /*----------------------------------
      Duplicate Logos
    -----------------------------------*/

    track.innerHTML += track.innerHTML;

    let position = 0;
    let animationFrame;

    let speed = 0.7;

    const maxScroll = track.scrollWidth / 2;

    function animate() {

        position += speed;

        if (position >= maxScroll) {

            position = 0;

        }

        track.style.transform = `translateX(-${position}px)`;

        animationFrame = requestAnimationFrame(animate);

    }

    animate();

    /*----------------------------------
      Pause on Hover
    -----------------------------------*/

    slider.addEventListener("mouseenter", () => {

        cancelAnimationFrame(animationFrame);

    });

    slider.addEventListener("mouseleave", () => {

        animate();

    });

    /*----------------------------------
      Touch Support
    -----------------------------------*/

    let startX = 0;

    slider.addEventListener("touchstart", e => {

        cancelAnimationFrame(animationFrame);

        startX = e.touches[0].clientX;

    });

    slider.addEventListener("touchmove", e => {

        const currentX = e.touches[0].clientX;

        const delta = startX - currentX;

        position += delta;

        if (position < 0) position = 0;

        if (position > maxScroll) {

            position = 0;

        }

        track.style.transform = `translateX(-${position}px)`;

        startX = currentX;

    });

    slider.addEventListener("touchend", () => {

        animate();

    });

    /*----------------------------------
      Visibility Change
    -----------------------------------*/

    document.addEventListener("visibilitychange", () => {

        if (document.hidden) {

            cancelAnimationFrame(animationFrame);

        } else {

            animate();

        }

    });

});